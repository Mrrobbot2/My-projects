// STU NO: 220107753
// NAME : Lungelo Dladla
public class Point {
	
	private double x;
	private double y;
	
	Point(){
	}
	
	Point(double X, double Y){
		Setx(X);
		Sety(Y);
	}
	//Setter methods for both x and y
	private void Setx(double x) {
		this.x = x;
	}
	
	private void Sety(double y) {
		this.y = y;
	}
	
	//getter methods for both x and y
	public double GetX() {
		return x;
	}
	public double GetY() {
		return y;
	}
	
	//toString method which will display the coordinates as (x,y) string.
	public String toString() {
		
		String numx = String.valueOf(GetX());
		String numy = String.valueOf(GetY());
		String out = "("+numx+", "+numy+")";
		return out;
	}
}
