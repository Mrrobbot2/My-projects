
public class Triangle {
	//instant of Points
	Point first = new Point();
	Point second = new Point();
	Point third = new Point();
	
	//constructers
	Triangle(){
		
	}
	Triangle(Point X1,Point X2, Point X3){
		this.first = X1;
		this.second = X2;
		this.third = X3;
	}
	
	// this method tell us how we going to get the distance of two points
   
	public double distance(Point one, Point two) {
		
		double onex = one.GetX();
		double oney = one.GetY();
		double twox = two.GetX();
		double twoy = two.GetY();

		double distance = Math.sqrt(Math.pow((onex - twox), 2) + Math.pow((oney - twoy), 2));
		return distance;
	}
	
   
   // the longest side of triangle
   
	public double getLongestSide() {
		
		double sideA = distance(first,second);
		double sideB = distance(first,third);
		double sideC = distance(second,third);
		
		double longest = sideA;
		if(sideB > longest) {
			longest = sideB;
		}
		if(sideC > longest) {
			longest = sideC;
		}
		return longest;
	}
	
   // the shortest side of triangle
   
	public double getShortestSide() {
			
			double sideA = distance(first,second);
			double sideB = distance(first,third);
			double sideC = distance(second,third);
			
			double shortest = sideA;
			if(sideB < shortest) {
				shortest = sideB;
			}
			if(sideC < shortest) {
				shortest = sideC;
			}
			return shortest;
	}
   
   // return the intermediate side of triangle
   
	public double getIntermediateSide() {
		
		double sideA = distance(first,second);
		double sideB = distance(first,third);
		double sideC = distance(second,third);
		
		
		double inter;
		if(sideA > sideB && sideA < sideC) {
			inter = sideA;
		}
		else if(sideA < sideB && sideA > sideC) {
			inter = sideA;
		}
		else if(sideB > sideA && sideB < sideC) {
			inter = sideB;
		}
		else if(sideB < sideA && sideB > sideC) {
			inter = sideB;
		}
		else {
			inter = sideC;
		}
		
		return inter;
	}
   
   // this is where we check wheather the points of a triangle are formed or not
   
	public boolean testTriangle() {
		double longest = getLongestSide();
		double add = getShortestSide() + getIntermediateSide();
		if(longest < add) {
			return true;
		}
		else {
			return false;
		}
	}
	
   // the return of a method parameter
   
	public double perimeter() {
		return getShortestSide() + getIntermediateSide() + getLongestSide();
	}
	
   // the return of a method area
   
	public double Area() {
		double s = perimeter()/2;
		double A = Math.sqrt(s*(s-getShortestSide())*(s-getIntermediateSide())*(s-getLongestSide()));
		return A;
	}
	
  //this is where were told wheather it is regular, symmetric or irregular
   
	public String classifyTriangle() {
		if(getShortestSide()==getIntermediateSide() && getLongestSide()==getIntermediateSide()) {
			return "regular";
		}
		
		if(getShortestSide() == getIntermediateSide() || getLongestSide() == getIntermediateSide() || getLongestSide() == getShortestSide()) {
			return "symmetric";
		}
		return "irregular";
	}
}
