
import java.util.*;

public class TriangleTester {                    

	public static void main(String[] args) {
	
		double X,Y;
		
      System.out.println("Enter the coordimates of three points");
      
		Scanner scan = new Scanner(System.in);                           
      
		System.out.println("------------------1st point----------------");    // the user here will enter theire first coordinate    
		System.out.print("x1: ");
      X = scan.nextDouble();
		System.out.print("y1: ");
      Y = scan.nextDouble();
		Point A = new Point(X,Y);
      
		System.out.println("------------------2nd point----------------");   //the second coordiante       
		System.out.print("x2: "); 
      X = scan.nextDouble();
		System.out.print("y2: "); 
      Y = scan.nextDouble();
		Point B = new Point(X,Y);
      
		System.out.println("------------------3rd point----------------");   //the third coordinate   
		System.out.print("x3: "); 
      X = scan.nextDouble();
		System.out.print("y3: "); 
      Y = scan.nextDouble();
		Point C = new Point(X,Y);
      
		scan.close();
		Triangle tri = new Triangle(A,B,C);
      
      System.out.println("-------------Output Results--------------");
      
		System.out.println("The distance between "+A.toString()+" and "+B.toString()+" is: "+tri.distance(A,B));    //Distance between point(1) and point(2)
      
		System.out.println("The distance between "+A.toString()+" and "+C.toString()+" is: "+tri.distance(A,C));        //Distance between point(1) and (3)
      
		System.out.println("The distance between "+C.toString()+" and "+B.toString()+" is: "+tri.distance(B,C));           //Distance between point(3) and point(2)
      
		System.out.println("The longest side of the triangle formed by the three points is: "+tri.getLongestSide());       //this method return the longest side of triangle
             
		System.out.println("The shortest side of the triangle formed by the three points is: "+tri.getShortestSide());     //this method return the shortest side of triangle
      
		System.out.println("The intermediate side of the triangle formed by the three points is: "+tri.getIntermediateSide());      //this method return the intermediate side of triangle
      
		System.out.println("The perimeter of the triangle is: "+tri.perimeter());         // we get the parameter
      
		System.out.println("The area of the triangle is: "+ tri.Area());             // we get the area of triangle
      
		System.out.println("The triangle is "+ tri.classifyTriangle());             // this method return wheather it is irregular, regular or symmetric
	}
}
