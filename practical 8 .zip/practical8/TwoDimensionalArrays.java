import java.io.*;
import java.util.*;
public class TwoDimensionalArrays{
   static double[][] tempAr= new double[12][2];
   public static double avgHighTemp(){
      double answer = 0;
      for(int i =0;i<tempAr.length;i++)
         answer += tempAr[i][0];
      return answer/tempAr.length;
   }
   
   public static double avgLowTemp(){
      double answer = 0;
      for(int i =0;i<tempAr.length;i++)
         answer += tempAr[i][1];
      return answer/tempAr.length;
   }
   
   public static double hieghestTemp(){
      double highest =tempAr[0][0];
      for(int i=1;i < tempAr.length;i++){
         if(tempAr[i][0] > highest)
            highest =tempAr[i][0];
      }
      return highest;
   }
   
   public static double lowestTemp(){
      double lowest =tempAr[0][1];
      for(int i=1;i < tempAr.length;i++){
         if(tempAr[i][1] < lowest)
            lowest =tempAr[i][1];
      }
      return lowest;
   }
   public static void saveTemp()throws FileNotFoundException{
      PrintWriter pw = new PrintWriter(new File("Temperatures.txt"));
      for(int i=0;i<tempAr.length;i++){
         for(int j=0;j<tempAr[i].length;j++){
            pw.print(tempAr[i][j]+" ");
         }
         pw.println();
      }
      pw.close();
   }
   
   public static void main(String[] args)throws FileNotFoundException{
      Scanner scan = new Scanner(System.in);
      for(int i=0;i<tempAr.length;i++){
         for(int j=0;j<tempAr[i].length;j++){
            if(j % 2 == 0){
               System.out.print("Enter the highest Temperature for Month " + (i+1) +": ");
               tempAr[i][j] =  Double.parseDouble(scan.next());
            }
            else{
               System.out.print("Enter the Lowest  Temperature for Month " + (i+1) +": ");
               tempAr[i][j] =  Double.parseDouble(scan.next());
            }
         }
         System.out.println();
      }
      System.out.println("avgHighTemp() "+avgHighTemp());
      System.out.println("avgLowTemp()  "+avgLowTemp());
      System.out.println("HighestTemp()  "+hieghestTemp());
      System.out.println("LowestTemp()  "+lowestTemp());
      saveTemp();
      System.out.println();
      System.out.println("File saved");
      
   }
}