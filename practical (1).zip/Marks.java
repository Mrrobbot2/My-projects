//hello
//this program is about a student who sits in three examinations
//and this program takes three marks as input and outputs a message indicating either a PASS or FAIL or PASS by COMPENSATION

import java.util.*;
public class Marks{
public static void main(String[] args){
  Scanner read = new Scanner(System.in);
  
  //double variables
  double Mark;
  double Mark2;
  double Mark3;
  //ask the user to enter the three marks;
  
  System.out.print("Enter Mark:");
  Mark = read.nextDouble();
  
  System.out.print("Enter Mark2:");
  Mark2 = read.nextDouble();
  
  System.out.print("Enter Mark3:");
  Mark3 = read.nextDouble();
  
  //then  calc the average
  double average; 
  average = (Mark + Mark2 + Mark3) / 3;
  System.out.println("The average mark is="+average);
  
  System.out.println("");
  
  // use if else to finish the code
  if(average>=50)
   System.out.println("PASS");
  else if(average>=40)
   System.out.println("PASS by COMPENSATION");
  else
   System.out.println("FAIL");
  System.out.println("");
  
  System.out.println("");
  
   
  }
}
  

  