//this program will read a line a break it to two wrods
//where we ask the user to enter the line
//and the program the break the line 
import java.util.*;
public class Line{
  public static void main(String[] args){
    Scanner read = new Scanner(System.in);
  
    String line;
    System.out.println("Enter a line");
    System.out.print(":");
  
    line = read.nextLine();
    String words[] = line.split(" ");
    for(String w: words)
    {
    System.out.println(w);
  
    }
    //when you write aline it will be breaked into single words
    
    
    
  }
}