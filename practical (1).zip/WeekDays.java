
//Hello
//this program will help us find the day of the week that date belong on
//the user will enter month, year and day...then we use the Gregorian calender equations to find hte excact week.
//i hope you enjoy

import java.util.*;

public class WeekDays {
   public static void main(String[] args) {
   
      Scanner read = new Scanner(System.in);
      //this variables stated bellow must be in real numbers no decimals needed
      int month;
      int day ;
      int year;
    
      //Ask the user to enter month
      System.out.print("Enter month    : ");
      month = read.nextInt();
    
      //ask the user to enter day
      //the number of days must be less than or  equal to 31
      System.out.print("Enter day      : ");
      day = read.nextInt();
    
      //ask the user for a year
      System.out.print("Enter the year : ");
      year = read.nextInt();
      
          
      double m ;
      int y;
      int d0;
      
       
      //use the Gregorian calender to find variables
      m = month  + 12 *((14-month)/12)-2 ; 
      if(month<=2){
      year--;
   
      }
      y = year + year / 4 -year / 100 + year /400 ;
   
      d0 = (day + y +(31 *month)/12)%7  ;
      
      System.out.println("");
   
      System.out.println("Day of the week is : " +d0);
      
      System.out.println("");
      
      
      //once we have found the d0 then we use if else statements to finish our code
      if(d0==1)
      System.out.println("monday");
      
      else if (d0==2)
      System.out.println("tuesday");
      
      else if (d0==3)
      System.out.println("wednesday");
      
      else if (d0==4)
      System.out.println("thursday");
      
      else if (d0==5)
      System.out.println("Friday");
      
      else if (d0==6)
      System.out.println("Saturday");
      
      else if (d0==7)
      System.out.println("sunday");
      
      // thank you
   
   
   }
}