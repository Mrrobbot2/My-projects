import java.util.*;
public class ColourConversion{
public static void main(String[] args){
 Scanner read= new Scanner(System.in);
 
 //integer scale==0 to 255
 double r, g, b,w,c,m,y,k,max;
 System.out.print("Enter Red: "); r= read.nextDouble();
 System.out.print("Enter Green: ");g= read.nextDouble();
 System.out.print("Enter Blue: "); b= read.nextDouble();
 
 if(r  == 0 && g ==0 && b ==0)
   System.out.println("All the CMY value==0 and k value is 1");
 else
   System.out.println("");
   
 //we can try use the formuals below
 w= max (r/255,g/255,b/255);
 System.out.println(" W: "+w);
 
 c= (w-(r/255))/w;
 System.out.println("C: "+c);
 
 m = (w-(g/255))/w;
 System.out.println("M: "+m);
 
 y = (w-(b/255))/w;
 System.out.println("Y: "+y);
 
 k = 1-w;
 System.out.println("K: "+k);
 
 
 //cmyk values
 
 }
}

 