/**
 * A test program for the Circle class.
 * @author Luke
 */
public class CircleApplication {

  /**
   * The main entry-point for the program.
   * @param args no arguments required.
   */
  public static void main(String[] args) {
    Circle myCircle = new Circle();
    myCircle.setRadius(200);
    ShapeCanvas canvas = new ShapeCanvas();
    canvas.drawShape(myCircle);
    
    //this will represent the second part of the circle.
    Circle myCircleA = new Circle();
    myCircleA.setRadius(150);
    canvas.drawShape(myCircleA);
    
    //this will drw the second part of the third part of  the prac
    Circle myCircleB = new Circle();
    myCircleB.setRadius(120);
    canvas.drawShape(myCircleB);
    //stay well
  }
}
