/**
 * Fill this class in to implement your Rectangle class.
 * 
 * @author Luke
 */
 //ProvidethedefaultconstructorTriangle()anda parameterized/overloadedconstructorTriangle(doublea,doubleb, doublec)
public class Triangle{
  private double A;
  private double B;
  private double C;
  


  //default construtor
  public Triangle(){
  A = B= C = 0.0;
  }
  //parameterized constructor
  public Triangle(double A, double B, double C){
  this.A=A;
  this.B=B;
  this.C=C;
  }

  public double getA() {
    return 0.0;
  }

  public double getB() {
    return 0.0;
  }
  
  public double getC() {
    return 0.0;
  }

  public double getPerimeter() {
    return 0.0;
  }

  public double getArea() {
    return 0.0;
  //provide a set
  }
  public void setA(double A){
   this.A= A;
  }
  public void setB(double B){
   this.B= B;
  }
  public void setC(double C){
   this.C= C;
  }
  //Finally,fillinthegetPerimeter()andgetArea()methods.
  public double area(){
     double theArea;
     theArea = A*B*C;
     return theArea;
  }
   public double perimeter(){
     double thePerimeter;
     thePerimeter = (A +B + C)*2;
     return thePerimeter;




  
  
  
  }

}