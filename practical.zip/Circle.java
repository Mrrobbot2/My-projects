/**
 * A class which describes Circle objects.
 * @author Luke
 */
public class Circle {

  /**
   * The internal state of all Circle objects. They only need to 'know' their
   * radius in order to calculate area and perimeter.
   */
  private double radius;

  /**
   * Send a message to a Circle object to change its radius.
   * @param r the radius as a double-precision floating-point value.
   */
  public void setRadius(double r) {
    radius = r;
  }

  /**
   * Send a message to a Circle object to ask it for its radius.
   * @return the radius as a double-precision floating-point value.
   */
  public double getRadius() {
    return radius;
  }

  /**
   * Send a message to a Circle object to ask it for its perimeter/circumference.
   * @return the perimeter as a double-precision floating-point value.
   */
  public double getPerimeter() {
    return 2 * Math.PI * radius;
  }

  /**
   * Send a message to a Circle object to ask it for its area.
   * @return the area as a double-precision floating-point value.
   */
  public double getArea() {
    return Math.PI * radius * radius;
  }
}
