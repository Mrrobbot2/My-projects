
/**
 * Fill in this class body to implement a point in the Cartesian plane.
 * @author Luke
 */
public class MyPoint1 {
  //variable or properties or data  of the class
  private double X;
  private double Y;
  
  //default constructors
  public MyPoint1(){
    X=Y=0.0;
  }
  
  //parameterized or overloaded constructor
  public MyPoint1(double X, double Y){
  this.X=X;
  this.Y=Y;
  }
  
  //insert setters
  public void setX(double X){
   this.X=X;
  }
  public void setY(double Y){
   this.Y=Y;
  }
  
  //insert getters
  public double getX(){
    return X;
  }
  public double getY(){
    return Y;
  }
  
  public String toString(double X, double Y){
  String point= "("+X+" , "+Y+")";
  return point;
  }
}
