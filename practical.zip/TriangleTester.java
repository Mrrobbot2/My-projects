import java.util.*;
public class TriangleTester{
  public static void main(String[] args){
     Scanner read = new Scanner(System.in);
     double a;
     double b;
     double c;
     
     System.out.println("********Now we ask the user to enter a,b,c**********");
     System.out.println("   ");
     
     System.out.print("Enter A: ");
     a= read.nextDouble();
     
     System.out.print("Enter B: ");
     b= read.nextDouble();
     
     System.out.print("Enter C: ");
     c= read.nextDouble();
     




    
    double S= (1/2)*a+b+c;
    System.out.println("the semi perimeter of triangle is = "+ S);
    
    
    double W = S; //reason why im assigning w to s its because it says the number is undefined at my output, it doesnt know the s in that equation so i use W.

    double Area= Math.sqrt(W*W-a*W-b*W-c);
    System.out.println("the area of the triangle is= "+ Area+"");
    
       
   }
}