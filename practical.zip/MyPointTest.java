// this is my point test
import java.util.*;
public class MyPointTest{
   public static void main(String[] args){
   Scanner read= new Scanner(System.in);
   
   double X= 0.0;
   double Y= 0.0;
   
   System.out.println("****We now display the X and Y coordinates****");
   System.out.print(" Enter X: ");
   X = read.nextDouble();
   
   System.out.println("                           ");
   System.out.print(" Enter Y:  ");
   Y = read.nextDouble();
   
   System.out.println("                           ");
   System.out.println("The value of X coordinate is: "+ X+" and the value of Y coordinate is : "+Y+"");
   }
}

