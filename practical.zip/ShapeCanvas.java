import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.HeadlessException;
import java.awt.Shape;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JFrame;

/**
 * A canvas that knows how to draw 2D Shapes objects.
 * 
 * @author Luke
 */
public class ShapeCanvas extends JFrame {

  /**
   * ShapeCanvas constructor. It sets the size of the canvas, and tells it to
   * exit the program when the user closes the window.
   * 
   * @throws HeadlessException
   *           - thrown in rare cases where an operating system has no graphical
   *           user interface.
   */
  public ShapeCanvas() throws HeadlessException {
    this.setBounds(0, 0, 800, 600);
    this.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    this.setVisible(true);
    this.shapes = new Vector<Object>();
  }

  /**
   * Send a message to the canvas to draw a 2D shape object. The object is added
   * to a 'list' of objects - if the same object is added more than once, it
   * will only be drawn once.
   * 
   * @param c
   *          the shape object to draw.
   */
  public void drawShape(Object s) {
    this.shapes.add(s);
    repaint();
  }

  /*
   * (non-Javadoc)
   * 
   * @see java.awt.Window#paint(java.awt.Graphics)
   */
  @Override
  public void paint(Graphics g) {
    g.clearRect(0, 0, (int) this.getWidth(), (int) this.getHeight());
    double centerX = this.getWidth() / 2;
    double centerY = this.getHeight() / 2;
    Graphics2D g2d = (Graphics2D) g;
    int iteration = 1;
    for (Iterator<Object> i = shapes.iterator(); i.hasNext();) {
      Object shape = i.next();
      if (shape instanceof Circle) {
        Circle circle = (Circle) shape;
        double radius = circle.getRadius();
        Shape theCircle = new Ellipse2D.Double(centerX - radius, centerY - radius, 2.0 * radius, 2.0 * radius);
        g2d.draw(theCircle);
        this.setTitle("[" + iteration + "] Area: " + String.format("%.2f", circle.getArea()) + " Perimeter: "
            + String.format("%.2f", circle.getPerimeter()));
      }/* else if (shape instanceof Rectangle) {
        Rectangle rect = (Rectangle) shape;
        Shape theRect = new Rectangle2D.Double(centerX - rect.getWidth()/2, centerY - rect.getHeight()/2, rect.getWidth(), rect.getHeight());
        g2d.draw(theRect);
        this.setTitle("[" + iteration + "] Area: " + String.format("%.2f", rect.getArea()) + " Perimeter: "
            + String.format("%.2f", rect.getPerimeter()));
      }*/ else {
        throw new IllegalStateException("Unrecognised 2D shape.");
      }
      iteration++;
    }
  }

  /**
   * A list of 2D Shape objects to draw.
   */
  private Vector<Object> shapes;
}
