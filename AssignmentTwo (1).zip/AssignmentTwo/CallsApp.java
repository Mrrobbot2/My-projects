import java.io.*;
import java.util.*;

public class CallsApp{

   public static String[][] getCallsData()throws IOException{
    Scanner m = new Scanner(new File("calls.txt"));
    String[][] callsArr = new String[5][5];
    while(m.hasNextLine()){
      for(int i=0;i<callsArr.length;i++){
         String line = m.nextLine();
         String[] newLine = line.split("   ");
         for(int j=0;j<callsArr[i].length;j++){
           if(newLine[i].equals("  ")){
            callsArr[i][j] = "  "; 
           }
           else
              callsArr[i][j] = newLine[j];
         }

       }
    }
    return callsArr;
  }
  
  public static double[] getWeeklyCost(String[][] callsArr1){
    double[] costsAr = new double [callsArr1.length];
    double num = 0.0;
    for(int i=0;i<callsArr1.length;i++){
      num = 0.0;
      if(i==4){
        for(int n=0;n<2;n++){
          num +=(Double.parseDouble(callsArr1[i][n]))*1.2;
        }
        costsAr[i] = num;
      }
       else{
            for(int j=0;j<callsArr1[i].length;j++){
              num += (Double.parseDouble(callsArr1[i][j]))*1.2;
            }
        
      costsAr[i] = num;
     }
    }
    return costsAr;
  }
  
  
  public static int getLongestCall(String[][] callsArr1){
    int longCall = 0;
    for(int i=0;i<callsArr1.length;i++){
      if(i==4){
        for(int n=0;n<2;n++){
          if(Integer.parseInt(callsArr1[i][n])>longCall){
           longCall = Integer.parseInt(callsArr1[i][n]);
         }
        }
       }
       else{
         for(int j=0;j<callsArr1[i].length;j++){
           if(Integer.parseInt(callsArr1[i][j])>longCall){
              longCall = Integer.parseInt(callsArr1[i][j]);
            }
          }
        }
     }
     return longCall;
  }

  public static int getShortestCall(String[][] callsArr1){
    int shortCall = Integer.MAX_VALUE;
    for(int i=0;i<callsArr1.length;i++){
      if(i==4){
        for(int n=0;n<2;n++){
          if(Integer.parseInt(callsArr1[i][n])<shortCall){
               shortCall = Integer.parseInt(callsArr1[i][n]);
          }
        }
      }
      else{
            for(int j=0;j<callsArr1[i].length;j++){
              if(Integer.parseInt(callsArr1[i][j])<shortCall){
                 shortCall = Integer.parseInt(callsArr1[i][j]);
               }
             }
         }
     }
     return shortCall;
  }

  
  public static double averageCallTime(String[][] callsArr1){
    double count = 0.0;
    double sum = 0.0;
    
    for(int i=0;i<callsArr1.length;i++){
      if(i==4){
         for(int n=0;n<2;n++){
            sum += Double.parseDouble(callsArr1[i][n]);
            count++;
         }
      }
      else if(i<4){
    
      for(int j=0;j<callsArr1[i].length;j++){

           sum += Double.parseDouble(callsArr1[i][j]);
           count++;
         }
       }
     }
     double averCallTime = sum/count;
     return averCallTime;
  }
  
  
  public static void displayWeeklyCosts(double[] costsAr){
    for(int i=0;i<costsAr.length;i++){
       System.out.printf("  Week "+(i+1)+": R"+costsAr[i]+"%43s","");
       System.out.println();
    }
  }

  
  public static void main(String[] args)throws IOException{
  
  System.out.println("  CALLS DATA                                              ");
  System.out.println(" ");
  String[][] callsArr1 = getCallsData(); 
    for(int i=0;i<callsArr1.length;i++){
      System.out.printf("  ");
      if(i == 4){
          for(int n =0;n<2;n++){
             System.out.print(callsArr1[i][n]+" "); 
       }
       System.out.printf("%51s","");
      }
      else{
         for(int j=0;j<callsArr1[i].length;j++){
            System.out.print(callsArr1[i][j]+" "); 
          }
          System.out.printf("%42s","*");
       }
       System.out.println();
     
     System.out.printf(""+"%59s","");
     System.out.println();
     System.out.println("");
     System.out.printf(""+"%59s","");
     System.out.println();
     System.out.println("  Weekly Calls Cost: "+Arrays.toString(getWeeklyCost(callsArr1))+"  ");
     System.out.printf(""+"%59s","");
     System.out.println();
     System.out.printf("  Longest Call: "+getLongestCall(callsArr1)+"%41s","");
     System.out.println(" ");
     System.out.printf("  Shortest Call: "+getShortestCall(callsArr1)+"%40s","");
     System.out.println();
     System.out.printf(""+"%59s","");
     System.out.println();
     System.out.printf("  Average Call Time: "+averageCallTime(callsArr1)+"%34s","");
     System.out.println();
     
     System.out.println();
     System.out.println("  WEEKLY COSTS                                            ");
     
     System.out.println(" ");
     displayWeeklyCosts(getWeeklyCost(callsArr1));
     
     }
  }
}