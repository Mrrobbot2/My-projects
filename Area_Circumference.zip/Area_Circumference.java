//Hello sir, this is practical2


import java.util.*;

public class Area_Circumference{//first part of java programm where we find the area of a circle with the circumference.
   public static void main(String[] args){
   float radius;
   double area, circumference;
   Scanner user_input= new Scanner(System.in);
   
System.out.print("enter radius: ");
    radius = user_input.nextFloat();
   area= 3.14*radius*radius;
   System.out.println(" the Area of a Circle is;" +area+"");
   circumference = 2*3.14*radius;
   System.out.println(" the circumference of the circle is;" +circumference+"");

System.out.println("                                    "); //this will help us to skip a space so that our programm is clear, 
 
 // second part of prac

 float Area;
 Scanner read= new Scanner(System.in);
 double radius1;
 System.out.println("enter radius1:  ");
 radius1= read.nextDouble();
 
 double radius2;
 System.out.print("enter radius2:  ");
 radius2= read.nextDouble();
 
 area= 3.14*radius1*radius2;//equation of area of ellipse
 //after finding area of ellipse we find the circum of ellipse.
 circumference= 2* 3.14 *Math.sqrt((Math.pow(radius1,2)+Math.pow(radius2,2))/2);// this equation will help us find the circumference of ellpse

 
  
 System.out.println(" Area OF ELLIPSE= " +area+"");
 System.out.println("circumference of ellipse ="+ circumference+"");

 
System.out.println("                                       ");
//third part of our prac
//were calculating loans

//Scanner read= new Scanner(System.in);
double P;
System.out.print("enter P: ");//this is where a user will enter the amount
P= read.nextDouble();

double N;
System.out.print("enter N: ");
N = read.nextDouble();

double R;
System.out.print("enter R: ");
R = read.nextDouble();



double A = P*(1 + Math.pow((R/100),N))*R/100 / (1 + Math.pow((R/100),N))-1;// this is the equation of finding A.
System.out.println("the amount owed is= "+A+"");

System.out.println("                             ");


// last part of our prac.

double a;
System.out.print("enter a: ");
a= read.nextDouble();

double b;
System.out.print("enter b: ");
b= read.nextDouble();

double c;
System.out.print("enter c: ");
c= read.nextDouble();

double perimeter_of_triangle = a+b+c;
System.out.println("the perimeter of tirangle is= "+ perimeter_of_triangle);

double S= (1/2)*a+b+c;
System.out.println("the semi perimeter of triangle is = "+ S);

double W = S; //reason why im assigning w to s its because it says the number is undefined at my output, it doesnt know the s in that equation so i use W.

double Area_1= Math.sqrt(W*W-a*W-b*W-c);
System.out.println("the area of the triangle is= "+ Area_1+"");
// stay well
 }
}